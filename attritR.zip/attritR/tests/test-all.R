library(testthat)
test_check("attritR")
